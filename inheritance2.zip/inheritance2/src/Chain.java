import java.util.List;

public class Chain  {
    private List<Store> Stores;

    public Chain(List<Store> stores) {
        Stores = stores;
    }
    public String OutOfStock(int minNum){
        String list="";
        for(Store store:this.Stores){
            list += store.OutOfStock(minNum);
        }
        return list;
    }

    public double ChainValue(){
        double value=0;
        for(Store store:this.Stores){
           value += store.StoreValue();
        }
        return value;
    }

}
