public class EarBuds extends Product{
    protected double Range;

    public EarBuds(String manufacturer, String model, double price, int stockN, double range) {
        super(manufacturer, model, price, stockN);
        Range = range;
    }
}
