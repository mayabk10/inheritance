import java.util.List;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Mp4 Mishmish = new Mp4("a","s",1,3,true,false,11);
        EarBuds Amir = new EarBuds("b","w",2,4,3);
        List<Product>List1 = List.of(Mishmish,Amir);
        Store store = new Store(List1);
        List<Store> Stores = List.of(store);
        Chain chain = new Chain(Stores);
        System.out.println(store.StoreValue());
        System.out.println(chain.ChainValue());
        System.out.println(store.OutOfStock(5));
        System.out.println(chain.OutOfStock(4));



    }
}