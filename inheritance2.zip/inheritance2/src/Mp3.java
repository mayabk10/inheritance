public class Mp3 extends Product{
    protected boolean Radio;
    protected boolean Speaker;

    public Mp3(String manufacturer, String model, double price, int stockN, boolean radio, boolean speaker) {
        super(manufacturer, model, price, stockN);
        Radio = radio;
        Speaker = speaker;
    }
}
