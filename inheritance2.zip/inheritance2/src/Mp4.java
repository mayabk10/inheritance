public class Mp4 extends Mp3{
    protected double ScreenL;

    public Mp4(String manufacturer, String model, double price, int stockN, boolean radio, boolean speaker, double screenL) {
        super(manufacturer, model, price, stockN, radio, speaker);
        ScreenL = screenL;
    }
}
