public class Product {
    protected String Manufacturer;
    protected String Model;
    protected double Price;
    protected int StockN;

    public int getStockN() {
        return StockN;
    }

    public String getModel() {
        return Model;
    }

    public double getPrice() {
        return Price;
    }

    public Product(String manufacturer, String model, double price, int stockN) {
        Manufacturer = manufacturer;
        Model = model;
        Price = price;
        StockN = stockN;
    }
}
