import java.util.List;

public class Store {
    private List<Product> Products;

    public Store(List<Product> products) {
        Products = products;
    }
    public String OutOfStock(int minNum){
        String list="";
        for(Product product:this.Products){
            if(product.getStockN()<minNum){
                list += product.getModel() + " ";
            }
        }
        return list;
    }

    public double StoreValue(){
        double value=0;
        for(Product product:this.Products){
            value+= product.getPrice() * product.getStockN();
        }
        return value;
    }
}
